from django.http import JsonResponse, HttpResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser

from .models import Customer, Order, OrderItem
from .serializers import CustomerSerializer, OrderSerializer, OrderItemSerializer


# Create your views here.
@csrf_exempt
def customer_list(request):
    if request.method == 'GET':
        customer_list = Customer.objects.all()
        customer_list_serializer = CustomerSerializer(customer_list, many=True)
        return JsonResponse(customer_list_serializer.data, safe=False, status=200)


    elif request.method == 'POST':
        request_data = JSONParser().parse(request)
        add_customer_serializer = CustomerSerializer(data=request_data)
        if add_customer_serializer.is_valid():
            add_customer_serializer.save()
            return JsonResponse(add_customer_serializer.data, status=201)
        return JsonResponse(add_customer_serializer.errors, status=400)


@csrf_exempt
def customer_details_view(request, passed_id):
    # to get the single object based on the id
    try:
        customer_details = Customer.objects.get(c_id=passed_id)
    except Customer.DoesNotExist:
        return HttpResponse(status=404)
    if request.method == 'GET':
       customer_detail_serializer = CustomerSerializer(customer_details)
       return JsonResponse(customer_detail_serializer.data, safe=False, status=200)


    elif request.method == 'PUT':
        # for saving the data we need to parse to JSON format
        request_data = JSONParser().parse(request)
        customer_update_serializer = CustomerSerializer(customer_details, data=request_data)
        if customer_update_serializer.is_valid():
            customer_update_serializer.save()
            return JsonResponse(customer_update_serializer.data, safe=False, status=201)

        return JsonResponse(customer_update_serializer.errors, safe=False, status=400)

    elif request.method == 'DELETE':
        customer_details.delete()
        return HttpResponse(status=204)


@csrf_exempt
def order_list(request):
    if request.method == 'GET':
        order_list = Order.objects.all()
        order_list_serializer = OrderSerializer(order_list, many=True)
        return JsonResponse(order_list_serializer.data, safe=False, status=200)


    elif request.method == 'POST':
        request_data = JSONParser().parse(request)
        add_order_serializer = OrderSerializer(data=request_data)
        if add_order_serializer.is_valid():
            add_order_serializer.save()
            return JsonResponse(add_order_serializer.data, status=201)
        return JsonResponse(add_order_serializer.errors, status=400)


@csrf_exempt
def order_details_view(request, passed_id):
    # to get the single object based on the id
    try:
        order_details = Order.objects.get(o_id=passed_id)
    except Order.DoesNotExist:
        return HttpResponse(status=404)
    if request.method == 'GET':
       order_detail_serializer = OrderSerializer(order_details)
       return JsonResponse(order_detail_serializer.data, safe=False, status=200)


    elif request.method == 'PUT':
        # for saving the data we need to parse to JSON format
        request_data = JSONParser().parse(request)
        order_update_serializer = OrderSerializer(order_details, data=request_data)
        if order_update_serializer.is_valid():
            order_update_serializer.save()
            return JsonResponse(order_update_serializer.data, safe=False, status=201)

        return JsonResponse(order_update_serializer.errors, safe=False, status=400)

    elif request.method == 'DELETE':
        order_details.delete()
        return HttpResponse(status=204)

@csrf_exempt
def orderitem_list(request):
    if request.method == 'GET':
        orderitem_list = OrderItem.objects.all()
        order_item_list_serializer = OrderItemSerializer(orderitem_list, many=True)
        return JsonResponse(order_item_list_serializer.data, safe=False, status=200)


    elif request.method == 'POST':
        request_data = JSONParser().parse(request)
        add_order_item_serializer = OrderItemSerializer(data=request_data)
        if add_order_item_serializer.is_valid():
            add_order_item_serializer.save()
            return JsonResponse(add_order_item_serializer.data, status=201)
        return JsonResponse(add_order_item_serializer.errors, status=400)

@csrf_exempt
def orderitem_details_view(request, passed_id):
    # to get the single object based on the id
    try:
        orderitem_details = OrderItem.objects.get(oi_id=passed_id)
    except Order.DoesNotExist:
        return HttpResponse(status=404)
    if request.method == 'GET':
       orderitem_details_serializer = OrderItemSerializer(orderitem_details)
       return JsonResponse(orderitem_details_serializer.data, safe=False, status=200)


    elif request.method == 'PUT':
        # for saving the data we need to parse to JSON format
        request_data = JSONParser().parse(request)
        orderitem_update_serializer = OrderItemSerializer(orderitem_details, data=request_data)
        if orderitem_update_serializer.is_valid():
            orderitem_update_serializer.save()
            return JsonResponse(orderitem_update_serializer.data, safe=False, status=201)

        return JsonResponse(orderitem_update_serializer.errors, safe=False, status=400)

    elif request.method == 'DELETE':
        orderitem_details.delete()
        return HttpResponse(status=204)