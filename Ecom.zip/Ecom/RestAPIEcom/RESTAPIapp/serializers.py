from rest_framework import serializers

from .models import Order, Customer, OrderItem


class CustomerSerializer(serializers.ModelSerializer):

    name = serializers.RegexField(
        regex=r'^[a-zA-Z\s]*$',  # Allows only letters and spaces
        max_length=50,
        min_length=3,
        allow_blank=False,
        error_messages={
            'invalid': 'Name must contain only letters.',
            'max_length': 'Name must not exceed 50 characters.',
            'min_length': 'Name must be at least 3 characters long.'
        }
    )
    address = serializers.RegexField(
        regex=r'^[a-zA-Z0-9\s]*$',  # Allows letters, numbers, and spaces
        max_length=200,
        min_length=10,
        allow_blank=False,
        error_messages={
            'invalid': 'Address must contain only letters, numbers, and spaces.',
            'max_length': 'Address must not exceed 200 characters.',
            'min_length': 'Address must be at least 10 characters long.'
        }
    )

    class Meta:
        model = Customer
        fields = '__all__'

    def create(self, validated_data):
        validated_data['name'] = validated_data['name'] .title()
        return super().create(validated_data)


class OrderSerializer(serializers.ModelSerializer):
    c_id = serializers.PrimaryKeyRelatedField(queryset=Customer.objects.all())
    c_id_details = CustomerSerializer(source='c_id', read_only=True)
    class Meta:
        model = Order
        fields = ['o_id', 'order_date','c_id','c_id_details']

class OrderItemSerializer(serializers.ModelSerializer):

    o_id = serializers.PrimaryKeyRelatedField(queryset=Order.objects.all())
    o_id_details = OrderSerializer(source='o_id', read_only=True)
    class Meta:
        model = OrderItem
        fields = '__all__'

